import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorWalletComponent } from './mentor-wallet.component';

describe('MentorWalletComponent', () => {
  let component: MentorWalletComponent;
  let fixture: ComponentFixture<MentorWalletComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorWalletComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorWalletComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
