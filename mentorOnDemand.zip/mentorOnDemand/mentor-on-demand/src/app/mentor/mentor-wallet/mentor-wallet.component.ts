import { Component, OnInit } from '@angular/core';
import { MentorServiceService } from 'src/app/service/mentor-service.service';
import { AuthServiceService } from 'src/app/service/auth-service.service';

@Component({
  selector: 'app-mentor-wallet',
  templateUrl: './mentor-wallet.component.html',
  styleUrls: ['./mentor-wallet.component.css']
})
export class MentorWalletComponent implements OnInit {

  constructor(private mentorserivce:MentorServiceService,private userservice:AuthServiceService) { }
  wallet:any
loggedinuser:any

  ngOnInit() {

this.wallet=this.userservice.walletOfUser
this.loggedinuser=this.userservice.loggedInUser
  }

}
