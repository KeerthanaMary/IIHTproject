import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MentorSearchComponent } from './mentor/mentor-search/mentor-search.component';
import { UserLoginComponent } from './site/login/user-login.component';

import { MentorSkillsComponent } from './mentor/mentor-skills/mentor-skills.component';
import { AddCourseComponent } from './mentor/add-course/add-course.component';
import { EditCourseComponent } from './mentor/edit-course/edit-course.component';
import { MentorTrainingsComponent } from './mentor/mentor-trainings/mentor-trainings.component';
import { UserTrainingsComponent } from './user/user-trainings/user-trainings.component';
import { TrainingComponent } from './training/training.component';
import { MentorWalletComponent } from './mentor/mentor-wallet/mentor-wallet.component';
import { UserSignupComponent } from './site/signup/user-signup.component';


const routes: Routes = [
  {path:'mentors', component:MentorSearchComponent},
  {path:'wallet/:id',component:MentorWalletComponent},
  {path:'mentorSkills', component:MentorSkillsComponent},
  {path:'addCourse', component:AddCourseComponent},
  {path:'editCourse/:id', component:EditCourseComponent},
  {path:'login', component:UserLoginComponent},
  {path:'signup', component:UserSignupComponent},
  {path:'mentorTrainings/:id', component:MentorTrainingsComponent},
  {path:'userTrainings/:id', component:UserTrainingsComponent},
  {path:'training/:id', component:TrainingComponent},
  {path:'**', redirectTo:'mentors'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }