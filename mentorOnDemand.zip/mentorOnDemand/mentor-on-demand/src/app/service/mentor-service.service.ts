import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MentorServiceService {

  skills

  mentorUrl='http://localhost:4566/api/'

  constructor(private http: HttpClient) { }

  getSkills()
  {
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.get(this.mentorUrl+"mentor/getSkills",options)
  }
  getMyCourses(id:any)
  {
    let body = id
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.get(this.mentorUrl+"mentorTwo/getCoursesById/"+body,options)
  }
  addCourse(course:any)
  {
    let body = JSON.stringify(course.value)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.post(this.mentorUrl+"mentor/addCourse",body,options)
  }
  getMySubscribers(id:any)
  {
    let body = id
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.get(this.mentorUrl+"mentorTwo/getMySubscribers/"+body,options)
  }
  updateTrainingStatus(id:any,status:boolean)
  {
    let body = id+"/"+status
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.put(this.mentorUrl+"training/updateTrainingStatus/"+body,options)
  }

}
